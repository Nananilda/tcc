<?php
/**
 * Configuração de conexão do Ákron para hospedagem cPanel.
 * Este arquivo é carregado automaticamente por conexao.php.
 */

return [
    'host' => 'localhost',
    'porta' => '3306',
    'banco' => 'athenasd_akron',
    'usuario' => 'athenasdev',
    'senha' => 'Athenas@123',
];
