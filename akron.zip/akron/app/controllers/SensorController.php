<?php
/**
 * app/controllers/SensorController.php
 * Controller: SensorController
 * Faz a ponte entre as requisições (telas web e API) e o SensorModel.
 * Inclui validação, controle de acesso e log de ações.
 *
 * Existem duas portas de entrada para as mesmas regras:
 *   - processarRequisicao(): formulários web (POST + token CSRF);
 *   - executar():            usado diretamente pela API (api/sensores.php).
 */

require_once __DIR__ . '/../models/SensorModel.php';

class SensorController
{
    private SensorModel $model;
    private PDO $pdo;
    private bool $ehAdmin;

    public function __construct(PDO $pdo, bool $ehAdmin)
    {
        $this->pdo = $pdo;
        $this->model = new SensorModel($pdo);
        $this->ehAdmin = $ehAdmin;
    }

    // ── Despacho principal ───────────────────────────────────────────────────

    /**
     * Entrada para formulários web: confere o método (POST) e o token CSRF e
     * executa a ação pedida em $_POST['acao'].
     *
     * @return array{mensagem:string,erros:string[]}
     */
    public function processarRequisicao(): array
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return ['mensagem' => '', 'erros' => []];
        }

        // Validação CSRF única para qualquer POST
        if (!validarCSRF($_POST['csrf_token'] ?? '')) {
            return ['mensagem' => '', 'erros' => ['Token de segurança inválido.']];
        }

        return $this->executar($_POST['acao'] ?? '', $_POST);
    }

    /**
     * Executa uma ação de gestão de sensores. Reutilizado pela API.
     *
     * @param string $acao  'cadastrar', 'atualizar', 'excluir' ou 'toggle_status'
     * @param array  $dados campos da ação (sensor_id, nome, tipo, localizacao, status,
     *                      novo_status, confirmacao)
     * @return array{mensagem:string,erros:string[]}
     */
    public function executar(string $acao, array $dados): array
    {
        switch ($acao) {
            case 'cadastrar':
                [$mensagem, $erros] = $this->cadastrar($dados);
                break;

            case 'atualizar':
                [$mensagem, $erros] = $this->atualizar($dados);
                break;

            case 'excluir':
                [$mensagem, $erros] = $this->excluir($dados);
                break;

            case 'toggle_status':
                [$mensagem, $erros] = $this->toggleStatus($dados);
                break;

            default:
                return ['mensagem' => '', 'erros' => ['Ação desconhecida.']];
        }

        return compact('mensagem', 'erros');
    }

    // ── Validação compartilhada ──────────────────────────────────────────────

    /**
     * Valida os campos de um sensor (usado no cadastro e na edição).
     *
     * @return array{0:array,1:string[]} [campos já saneados, erros]
     */
    private function validarCamposSensor(array $dados): array
    {
        $erros = [];
        foreach (['nome','tipo','localizacao','status'] as $campo) if (isset($dados[$campo]) && !is_string($dados[$campo])) return [[],['Campo inválido: '.$campo]];
        $nome = trim($dados['nome'] ?? '');
        $tipo = trim($dados['tipo'] ?? '');
        $localizacao = trim($dados['localizacao'] ?? '');
        $status = $dados['status'] ?? 'ativo';

        $tamanhoNome = function_exists('mb_strlen') ? mb_strlen($nome, 'UTF-8') : strlen($nome);
        if ($tamanhoNome < 3) {
            $erros[] = 'Nome do sensor deve ter ao menos 3 caracteres.';
        }
        if ($tamanhoNome > 100) {
            $erros[] = 'Nome do sensor muito longo (máx 100 caracteres).';
        }
        if (!SensorModel::tipoValido($tipo)) {
            $erros[] = 'Tipo de sensor inválido.';
        }
        if (!in_array($status, SensorModel::STATUS, true)) {
            $erros[] = 'Status inválido.';
        }
        if (strlen($localizacao) > 150) {
            $erros[] = 'Localização muito longa (máx 150 caracteres).';
        }

        $estoqueId = filter_var($dados['estoque_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $estoque = false;
        if ($estoqueId) {
            $stmt = $this->pdo->prepare('SELECT id,status FROM estoques WHERE id=?');
            $stmt->execute([$estoqueId]);
            $estoque = $stmt->fetch();
        }
        if (!$estoque) $erros[] = 'Selecione um estoque válido.';
        elseif ($estoque['status'] !== 'ativo' && $status === 'ativo') $erros[] = 'Um sensor ativo deve pertencer a um estoque ativo.';
        $intervalo = filter_var($dados['intervalo_comunicacao'] ?? 300, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 86400]]);
        if ($intervalo === false) $erros[] = 'Intervalo de comunicação deve ser entre 1 e 86400 segundos.';
        $campos = ['nome' => $nome, 'tipo' => $tipo, 'localizacao' => $localizacao ?: null,
            'status' => $status, 'estoque_id' => $estoqueId, 'intervalo_comunicacao' => $intervalo];
        foreach (['limite_critico_min','limite_atencao_min','limite_atencao_max','limite_critico_max'] as $campo) {
            $bruto = $dados[$campo] ?? '';
            $campos[$campo] = ($bruto === '' || $bruto === null) ? null : lerNumero($bruto);
            if ($bruto !== '' && $bruto !== null && $campos[$campo] === null) $erros[] = 'Informe limites numéricos válidos.';
        }
        $anterior = null;
        foreach (['limite_critico_min','limite_atencao_min','limite_atencao_max','limite_critico_max'] as $campo) {
            if ($campos[$campo] === null) continue;
            if ($anterior !== null && $campos[$campo] <= $anterior) {
                $erros[] = 'Os limites devem seguir: crítico inferior < atenção inferior < atenção superior < crítico superior.';
                break;
            }
            $anterior = $campos[$campo];
        }
        return [$campos, $erros];
    }

    // ── Ações ────────────────────────────────────────────────────────────────

    /**
     * Valida e cadastra um novo sensor (somente admin).
     */
    private function cadastrar(array $dados): array
    {
        $mensagem = '';

        if (!$this->ehAdmin) {
            return [$mensagem, ['Acesso negado.']];
        }

        [$campos, $erros] = $this->validarCamposSensor($dados);
        if (!empty($erros)) {
            return [$mensagem, $erros];
        }

        try {
            $id = $this->model->cadastrar($campos);

            $this->registrarLog('SENSOR_CADASTRO', "Sensor ID $id: ".json_encode($campos,JSON_UNESCAPED_UNICODE));
            $mensagem = "Sensor \"{$campos['nome']}\" cadastrado com sucesso.";
        } catch (PDOException $e) {
            $erros[] = $this->erroDeBanco('salvar o sensor', $e);
        }

        return [$mensagem, $erros];
    }

    /**
     * Atualiza todos os dados de um sensor (nome, tipo, localização, status) — somente admin.
     */
    private function atualizar(array $dados): array
    {
        $mensagem = '';

        if (!$this->ehAdmin) {
            return [$mensagem, ['Acesso negado.']];
        }

        $sensorId = filter_var($dados['sensor_id'] ?? null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]) ?: 0;
        if ($sensorId <= 0) {
            return [$mensagem, ['ID de sensor inválido.']];
        }

        [$campos, $erros] = $this->validarCamposSensor($dados);
        if (!empty($erros)) {
            return [$mensagem, $erros];
        }

        try {
            $atual = $this->model->buscarPorId($sensorId);
            if (!$atual) return [$mensagem, ['Sensor não encontrado.']];
            if ($atual['tipo'] !== $campos['tipo']) {
                $consulta = $this->pdo->prepare('SELECT (SELECT COUNT(*) FROM leitura_sensor WHERE sensor_id=?) + (SELECT COUNT(*) FROM alertas WHERE sensor_id=?)');
                $consulta->execute([$sensorId,$sensorId]);
                if ((int) $consulta->fetchColumn() > 0) return [$mensagem, ['O tipo não pode ser alterado quando há leituras ou alertas. Cadastre outro sensor para preservar o histórico.']];
            }
            if ((int)$atual['estoque_id'] !== (int)$campos['estoque_id']) {
                $q=$this->pdo->prepare('SELECT COUNT(*) FROM alertas WHERE sensor_id=? AND automatico=1 AND normalizado_em IS NULL');$q->execute([$sensorId]);
                if ($q->fetchColumn()) return [$mensagem,['Normalize a condição ambiental antes de transferir o sensor para outro estoque.']];
            }
            $this->model->atualizar($sensorId, $campos);
            $this->registrarLog('SENSOR_EDICAO', "Sensor ID $sensorId: ".json_encode($campos,JSON_UNESCAPED_UNICODE));
            $mensagem = "Sensor \"{$campos['nome']}\" atualizado com sucesso.";
        } catch (PDOException $e) {
            $erros[] = $this->erroDeBanco('atualizar o sensor', $e);
        }

        return [$mensagem, $erros];
    }

    /**
     * Exclui um sensor — somente admin e só com a palavra "excluir" como confirmação.
     */
    private function excluir(array $dados): array
    {
        $mensagem = '';

        if (!$this->ehAdmin) {
            return [$mensagem, ['Acesso negado.']];
        }

        $sensorId = filter_var($dados['sensor_id'] ?? null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]) ?: 0;
        if ($sensorId <= 0) {
            return [$mensagem, ['ID de sensor inválido.']];
        }

        $confirmacao = trim($dados['confirmacao'] ?? '');
        $confirmacao = function_exists('mb_strtolower') ? mb_strtolower($confirmacao, 'UTF-8') : strtolower($confirmacao);
        if (!in_array($confirmacao,['excluir','desativar'],true)) {
            return [$mensagem, ['Para desativar, digite a palavra "excluir" no campo de confirmação.']];
        }

        try {
            $sensor = $this->model->buscarPorId($sensorId);
            if (!$sensor) {
                return [$mensagem, ['Sensor não encontrado.']];
            }

            $this->model->excluir($sensorId);
            $this->registrarLog('SENSOR_DESATIVACAO', "Sensor ID $sensorId: {$sensor['nome']}");
            $mensagem = "Sensor \"{$sensor['nome']}\" desativado com sucesso. Histórico preservado.";
        } catch (PDOException $e) {
            // 23000 = violação de integridade (ex.: sensor com leituras vinculadas)
            if ($e->getCode() === '23000') {
                error_log('[' . APP_NOME . '] Exclusão de sensor bloqueada por vínculo: ' . $e->getMessage());
                return [$mensagem, ['Este sensor possui registros vinculados (ex.: leituras) e não pode ser excluído. Considere desativá-lo.']];
            }
            return [$mensagem, [$this->erroDeBanco('excluir o sensor', $e)]];
        }

        return [$mensagem, []];
    }

    /**
     * Define o status de um sensor (ativo/inativo) — somente admin.
     */
    private function toggleStatus(array $dados): array
    {
        $mensagem = '';
        $erros = [];

        if (!$this->ehAdmin) {
            return [$mensagem, ['Acesso negado.']];
        }

        $sensorId = filter_var($dados['sensor_id'] ?? null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]) ?: 0;
        $novoStatus = $dados['novo_status'] ?? '';

        if ($sensorId <= 0) {
            return [$mensagem, ['ID de sensor inválido.']];
        }

        if (!in_array($novoStatus, SensorModel::STATUS, true)) {
            return [$mensagem, ['Status inválido.']];
        }

        try {
            // Confirma que o sensor existe antes de atualizar
            if (!$this->model->buscarPorId($sensorId)) {
                return [$mensagem, ['Sensor não encontrado.']];
            }

            if ($novoStatus === 'ativo') {
                $sensor = $this->model->buscarPorId($sensorId);
                if ($sensor['estoque_status'] !== 'ativo') return [$mensagem, ['Ative o estoque antes de ativar o sensor.']];
            }
            $this->model->atualizarStatus($sensorId, $novoStatus);
            $this->registrarLog('SENSOR_STATUS', "Sensor ID $sensorId → $novoStatus");
            $mensagem = "Status do sensor atualizado para \"$novoStatus\".";
        } catch (PDOException $e) {
            $erros[] = $this->erroDeBanco('alterar o status do sensor', $e);
        }

        return [$mensagem, $erros];
    }

    // ── Consulta pública (usada pelas telas e pela API) ──────────────────────

    /**
     * Retorna todos os sensores para exibição.
     * Em caso de erro devolve array vazio e acrescenta uma mensagem em $erros.
     */
    public function listarSensores(array &$erros = [], array $filtros = []): array
    {
        try {
            return $this->model->listarTodos($filtros);
        } catch (PDOException $e) {
            $erros[] = $this->erroDeBanco('consultar os sensores', $e);
            return [];
        }
    }

    /**
     * Retorna um sensor pelo ID (ou null se não existir) — usado na tela de edição.
     */
    public function buscarSensor(int $id): ?array
    {
        try {
            return $this->model->buscarPorId($id) ?: null;
        } catch (PDOException $e) {
            error_log('[' . APP_NOME . '] Erro ao buscar sensor: ' . $e->getMessage());
            return null;
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private function registrarLog(string $acao, string $detalhe): void
    {
        if (!function_exists('registrarLog')) {
            return;
        }

        // O log é secundário: se falhar (ex.: ação nova não aceita pela tabela de
        // logs), registra no log do servidor mas não desfaz nem mascara a operação.
        try {
            registrarLog($this->pdo, $_SESSION['usuario_id'] ?? null, $acao, $detalhe);
        } catch (Throwable $e) {
            error_log('[' . APP_NOME . '] Falha ao registrar log ' . $acao . ': ' . $e->getMessage());
        }
    }

    /**
     * Grava o erro técnico no log do servidor e devolve uma mensagem genérica
     * para o usuário (não expor detalhes do SQL na tela).
     */
    private function erroDeBanco(string $acao, PDOException $e): string
    {
        error_log('[' . APP_NOME . '] Erro ao ' . $acao . ': ' . $e->getMessage());
        return "Não foi possível $acao. Tente novamente.";
    }
}